videofileserver_ui.zip
├── start_server.sh         # Startskript (einfach ausführen)
├── video_server.py         # Flask-basierter Dateiserver
├── templates/index.html    # Modernes, dunkles UI mit Videoplayer
├── static/   
