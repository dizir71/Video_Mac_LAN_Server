# Video_Mac_LAN_Server

Ein einfacher, autostartfähiger Video-Server für macOS im lokalen Netzwerk.

## Features
- Automatische Indizierung von Videoverzeichnissen
- Vorschau und Abspielmöglichkeit im Browser
- Menüleistenintegration oder .plist-Autostart
- Light- und Darkmode
- Uploads mit Fortschrittsanzeige
- HTTP Basic Auth (optional)
