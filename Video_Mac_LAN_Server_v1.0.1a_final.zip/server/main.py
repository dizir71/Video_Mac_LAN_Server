# Hauptserver-Datei
print('Starte Video LAN Server...')