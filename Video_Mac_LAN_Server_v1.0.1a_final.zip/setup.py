#!/usr/bin/env python3
print('Setup-Skript für macOS Video LAN Server')