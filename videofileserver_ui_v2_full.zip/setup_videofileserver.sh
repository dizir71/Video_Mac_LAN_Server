#!/bin/bash
echo 'Setup mit Autostart und Indexierung'