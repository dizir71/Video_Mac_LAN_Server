#!/bin/bash
echo 'Setup startet…'